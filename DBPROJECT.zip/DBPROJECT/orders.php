<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Rice_Mill_Systems";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">************* Order Detail **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Order id</th>
<th>Order Date</th>
<th>Weight(50 KG)</th>
<th>Payment Type</th>
<th>Customer ID</th>
<th>Stock ID</th>

</tr>
<?php
$sql = "SELECT * FROM orders";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['order_id'];?></td>
<td> <?php  echo $row['order_date'];?></td>
<td> <?php  echo $row['Weight_50kg'];?></td>
<td> <?php  echo $row['Payment_Type'];?></td>
<td> <?php  echo $row['customer_id'];?></td>
<td> <?php  echo $row['stock_id'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>