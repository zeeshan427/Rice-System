<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Rice_Mill_Systems";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">************* Machine RECORD **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Machine id</th>
<th>Machine Name</th>
<th>Machine Cost</th>
<th>Working</th>
<th>Rice ID</th>
<th>Employee ID</th>

</tr>
<?php
$sql = "SELECT * FROM Machines";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['machine_id'];?></td>
<td> <?php  echo $row['machine_name'];?></td>
<td> <?php  echo $row['machine_cost'];?></td>
<td> <?php  echo $row['working'];?></td>
<td> <?php  echo $row['rice_id'];?></td>
<td> <?php  echo $row['Employee_id'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>