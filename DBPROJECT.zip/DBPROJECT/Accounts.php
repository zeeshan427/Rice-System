<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Rice_Mill_Systems";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">************* Accounts RECORD **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Account id</th>
<th>CurrentBalance</th>
<th>Payable Bill Date</th>
<th>Payable Tax Date</th>
<th>Tax Amount</th>
<th>Per Unit Cost</th>
<th>Bill Amount</th>
<th>Production ID</th>

</tr>
<?php
$sql = "SELECT * FROM Accounts";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['account_id'];?></td>
<td> <?php  echo $row['current_balance'];?></td>
<td> <?php  echo $row['payable_bill_date'];?></td>
<td> <?php  echo $row['payable_tax_date'];?></td>
<td> <?php  echo $row['tax_amount'];?></td>
<td> <?php  echo $row['per_unit_cost'];?></td>
<td> <?php  echo $row['Bill_Amount'];?></td>
<td> <?php  echo $row['production_id'];?></td>


 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>