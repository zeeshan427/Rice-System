<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Rice_Mill_Systems";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">************* Rice Detail **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Rice id</th>
<th>Rice name</th>
<th>Quality</th>
<th>Year</th>
<th>Rice cost</th>

</tr>
<?php
$sql = "SELECT * FROM rice";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['rice_id'];?></td>
<td> <?php  echo $row['rice_name'];?></td>
<td> <?php  echo $row['quality'];?></td>
<td> <?php  echo $row['years'];?></td>
<td> <?php  echo $row['rice_cost'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>