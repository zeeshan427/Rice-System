<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Rice_Mill_Systems";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">************* Production RECORD **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Production id</th>
<th>Unit Burns</th>
<th>Production Date</th>
<th>Packs</th>
<th>Machine id</th>


</tr>
<?php
$sql = "SELECT * FROM Production";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['production_id'];?></td>
<td> <?php  echo $row['unit_burns'];?></td>
<td> <?php  echo $row['production_date'];?></td>
<td> <?php  echo $row['Packs'];?></td>
<td> <?php  echo $row['machine_id'];?></td>



 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>