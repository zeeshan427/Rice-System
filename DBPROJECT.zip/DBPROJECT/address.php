<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Rice_Mill_Systems";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">************* Address RECORD **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Address id</th>
<th>House NO</th>
<th>City</th>
<th>Street No</th>
<th>Area name</th>

</tr>
<?php
$sql = "SELECT * FROM Address";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['address_id'];?></td>
<td> <?php  echo $row['House_No'];?></td>
<td> <?php  echo $row['City'];?></td>
<td> <?php  echo $row['Street_No'];?></td>
<td> <?php  echo $row['Area_Name'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>